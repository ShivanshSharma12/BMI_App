import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LOGINPAGE extends StatefulWidget {
  const LOGINPAGE({super.key});

  @override
  State<LOGINPAGE> createState() => _LOGINPAGEState();

}

class _LOGINPAGEState extends State<LOGINPAGE> {
  TextEditingController ttt = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(body: Column(
        children: [
          TextField(
            controller: ttt,
      obscureText: true ,
      decoration: const InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(50))
        ),
        prefixIcon: Icon(Icons.search),
      ),),
      TextField(
            controller: ttt,
      obscureText: true ,
      decoration: const InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(50))
        ),
        prefixIcon: Icon(Icons.search),
      ),),
      SizedBox(height: 2,),
      Text("HEllo FlUTTER", style: TextStyle(fontSize: 30),
      ),
      Text("HELLO JI", style: GoogleFonts.anonymousPro(fontSize: 50),),
      // Container(height: 200, width: 200,
      // decoration: BoxDecoration(gradient: RadialGradient(colors: [Colors.red, Colors.blue, Colors.orange])
      // ),),
      SizedBox(
        width: 200,
        height: 200,
        child: Card(color: Colors.green,
        elevation: 10,
        shadowColor: Colors.red,
        child: Center(child: Text("hello")),),
      ),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children:[ const Chip(label: Text("Food"),
        avatar: CircleAvatar(child: Text("🍕"),),
        deleteIcon: Icon(Icons.delete),
        deleteIconColor: Colors.red,),
        const Chip(label: Text("Food"),
        avatar: CircleAvatar(child: Text("🍕"),),
        deleteIcon: Icon(Icons.delete),
        deleteIconColor: Colors.red,),
        const Chip(label: Text("Food"),
        avatar: CircleAvatar(child: Text("🍕"),),
        deleteIcon: Icon(Icons.delete),
        deleteIconColor: Colors.red,),
        const Chip(label: Text("Food"),
        avatar: CircleAvatar(child: Text("🍕"),),
        deleteIcon: Icon(Icons.delete),
        deleteIconColor: Colors.red,),
        
        
        

        ],),
        SizedBox(
          width: double.infinity,
          height: 100,
          child: ListTile(shape: CircleBorder(eccentricity: 0.3),
          ),
          
      )])
          )
      ,);
    
  }
}