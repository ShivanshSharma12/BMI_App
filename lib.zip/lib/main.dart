import 'package:bmi_app/screens/firstpage.dart';
import 'package:bmi_app/screens/loginform.dart';
import 'package:flutter/material.dart';

void main(){
  
  runApp(const MaterialApp(
    // routes: ,
    home: LOGINPAGE(),
  
  ));
}